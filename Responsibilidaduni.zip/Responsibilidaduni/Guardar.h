#ifndef GUARDAR_H
#define GUARDAR_H
#include <iostream>
#include "Libro.h"
using namespace std;

// Esta clase SOLO se encarga de guardar
class Guardar {
public:
	void guardarLibro(Libro libro);
};

#endif
