#include "Guardar.h"

void Guardar::guardarLibro(Libro libro) {
	cout << "Guardando: " << libro.titulo << " de " << libro.autor << endl;
}
