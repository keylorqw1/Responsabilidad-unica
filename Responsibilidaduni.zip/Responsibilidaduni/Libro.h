#ifndef LIBRO_H
#define LIBRO_H
#include <iostream>
using namespace std;

// Esta clase SOLO guarda los datos del libro
class Libro {
public:
	string titulo;
	string autor;
};

#endif
