#include <iostream>
#include "Libro.h"
#include "Guardar.h"
using namespace std;

int main() {
	Libro libro;
	libro.titulo = "cazador de utopias imposibles";
	libro.autor = "lechuga";
	
	Guardar guardar;
	guardar.guardarLibro(libro);
	
	return 0;
}
